My Free Budget — Android App

Version: 1.7.0
Version code: 7
Application ID: com.myfreebudget.app
Target SDK: 36

Features through Version 7:
- Income, expenses, savings and automatic duplicate merging
- Monthly budgets and summaries
- Spending dashboard and category chart
- Automatic saving advice
- Savings goals
- Dated reminders and Android notification scheduling
- Optional PIN lock and native biometric prompt on supported Android versions
- JSON backup and restore
- CSV export
- Monthly financial reports and printable/PDF-style reports

Build:
This repository includes a GitHub Actions workflow. It uses Gradle 8.13 and Android SDK 36 and does not require a Gradle wrapper in the repository.

Google Play:
The first GitHub build is an unsigned release AAB unless a signing configuration is added. A persistent upload key is required for publishing and for future updates.
