package com.myfreebudget.app;

import android.Manifest;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (android.os.Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        String text = intent.getStringExtra("text");
        if (text == null || text.isEmpty()) text = "Check your budget today.";
        NotificationCompat.Builder b = new NotificationCompat.Builder(context, "budget_reminders")
                .setSmallIcon(com.myfreebudget.app.R.drawable.app_icon)
                .setContentTitle("My Free Budget")
                .setContentText(text)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);
        NotificationManagerCompat.from(context).notify(Math.abs(text.hashCode()), b.build());
    }
}
