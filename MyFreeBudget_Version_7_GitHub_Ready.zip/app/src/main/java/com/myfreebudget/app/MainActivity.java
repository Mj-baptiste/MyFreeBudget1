package com.myfreebudget.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.graphics.Color;

import androidx.annotation.RequiresApi;

import android.hardware.biometrics.BiometricPrompt;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 701;
    private static final int CREATE_FILE_REQUEST = 702;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        createNotificationChannel();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244, 247, 251));
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AppBridge(this), "Android");

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);

        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "budget_reminders",
                    "Budget reminders",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription("Reminders from My Free Budget");
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    public void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST && webView != null) {
            webView.evaluateJavascript("window.notificationPermissionResult && window.notificationPermissionResult()", null);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public class AppBridge {
        private final MainActivity activity;
        AppBridge(MainActivity activity) { this.activity = activity; }

        @JavascriptInterface
        public String isBiometricAvailable() {
            return Build.VERSION.SDK_INT >= 28 ? "true" : "false";
        }

        @JavascriptInterface
        public void authenticateBiometric() {
            if (Build.VERSION.SDK_INT < 28) return;
            activity.runOnUiThread(() -> showBiometricPrompt());
        }

        @RequiresApi(28)
        private void showBiometricPrompt() {
            Executor executor = activity.getMainExecutor();
            BiometricPrompt.AuthenticationCallback callback = new BiometricPrompt.AuthenticationCallback() {
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                    super.onAuthenticationSucceeded(result);
                    if (webView != null) webView.evaluateJavascript("window.biometricUnlocked && window.biometricUnlocked()", null);
                }
                @Override public void onAuthenticationError(int errorCode, CharSequence errString) { super.onAuthenticationError(errorCode, errString); }
                @Override public void onAuthenticationFailed() { super.onAuthenticationFailed(); }
            };
            BiometricPrompt prompt = new BiometricPrompt(activity, executor, callback);
            BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Unlock My Free Budget")
                    .setSubtitle("Use your phone's biometric authentication")
                    .setNegativeButtonText("Use PIN")
                    .build();
            prompt.authenticate(info);
        }

        @JavascriptInterface
        public void requestNotifications() {
            activity.runOnUiThread(activity::requestNotificationPermission);
        }

        @JavascriptInterface
        public void scheduleReminder(String text, String date) {
            try {
                java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
                f.setLenient(false);
                java.util.Date d = f.parse(date);
                java.util.Calendar c = java.util.Calendar.getInstance();
                c.setTime(d);
                c.set(java.util.Calendar.HOUR_OF_DAY, 9);
                c.set(java.util.Calendar.MINUTE, 0);
                c.set(java.util.Calendar.SECOND, 0);
                c.set(java.util.Calendar.MILLISECOND, 0);
                if (c.getTimeInMillis() <= System.currentTimeMillis()) return;

                Intent i = new Intent(activity, ReminderReceiver.class);
                i.putExtra("text", text);
                int id = Math.abs((text + date).hashCode());
                PendingIntent pi = PendingIntent.getBroadcast(activity, id, i,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                AlarmManager am = (AlarmManager) activity.getSystemService(Context.ALARM_SERVICE);
                if (am != null) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void saveTextFile(String fileName, String content, String mimeType) {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(mimeType == null ? "text/plain" : mimeType);
            intent.putExtra(Intent.EXTRA_TITLE, fileName);
            activity.pendingFileContent = content;
            activity.startActivityForResult(intent, CREATE_FILE_REQUEST);
        }
    }

    private String pendingFileContent;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_FILE_REQUEST && resultCode == RESULT_OK && data != null && pendingFileContent != null) {
            try {
                Uri uri = data.getData();
                if (uri != null) {
                    try (java.io.OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out != null) out.write(pendingFileContent.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                    }
                }
            } catch (Exception ignored) { }
        }
        pendingFileContent = null;
    }
}
